<?php
session_start();
?>

    <?php
        require_once 'ClassPersonnel.php';
        
        if(isset($_POST["Envoyer"])){
            $code = $_POST['code'];
            $nom = $_POST['Nom'];
            $prenom = $_POST['Prenom'];
            $Sexe=$_POST['Sexe'];
            $Date_Naissance=$_POST['Date_Naissance'];
            $Nationalité=$_POST['Nationalité'];
            $Téléphone=$_POST['Téléphone'];
            $Email=$_POST['Email'];
            $Type= $_POST['Type'];
      $et = new Personnel($code,$nom,$prenom,$Sexe,$Date_Naissance,$Nationalité,$Téléphone,$Email,$Type);
      $t_et = [
        'code'=>$et->getCode(),
        'nom'=>$et->getNom(),
        'prenom'=>$et->getPrenom(),
        'Sexe'=>$et->getSexe(),
        'Date_Naissance'=>$et->getDate_Naissance(),
        'Nationalité'=>$et->getNationalité(),
        'Téléphone'=>$et->getTéléphone(),
        'Email'=>$et->getEmail(),
        'Type'=>$et->getType()
        ];
                        
      $_SESSION['Personnel'][]=$t_et;
            
                               
    }


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Uptown - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">ESIH</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Acceuil</a></li>
	          <li class="nav-item active"><a href="formulaire.php" class="nav-link">Enregistre Personnes</a></li>
            <li class="nav-item"><a href="agent.php" class="nav-link">Liste des Personnes</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	    
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2 ftco-degree-bg js-fullheight" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
          	<div style="margin:auto; padding:auto; width: 800px; height:auto; margin-top: 750px; z-index: 20px;">
              <div class="card">
                
                <div class="card-header" style="background-color: rgb(199, 64, 186); color:  white; font-size: 32px;">
                  Formulaire d'enregistrement des Personnes
                </div>
                <div class="card-body">
                  

            <fieldset>
              <legend></legend>
                <br>
              <form method="POST" action="formulaire.php">
                <label for="nom"> Code:</label>
                    <input id="Nom" type="text" name="code" placeholder="000 "size="50" required/>
                    <br><br>
                    <label for="nom"> Nom:</label>
                    <input id="Nom" type="text" name="Nom" placeholder="Nom "size="47.8" required/>
                    <br><br>
                    <label for="nom"> Prenom:</label>
                    <input id="Nom" type="text" name="Prenom" placeholder="Prenom "size="50" required/>
                    <br><br>
                    <label>Sexe</label>
                <br>
                <select name="Sexe" required>
                        <option value="Homme">Homme</option>
                        <option value="Femme">Femme</option>
                </select>
                <br><br>
                    Nationalite
                <select name="Nationalité" required>
                        <option value="Haitien">Haitien</option>
                        <option value="Americain">Americain</option>
                        <option value="Francais">Francais</option>
                        <option value="Canadien">Canadien</option>
                        <option value="Anglais">Anglais</option>
                        <option value="Bresilien">Bresilien</option>
                        <option value="Dominicain">Dominicain</option>
                </select>
                    <br><br>
                    <label>Date de naissance</label>	<input type="date" name="Date_Naissance"/>
                <br><br>
                <label for="nom">Telephone</label>
                <input id="Nom" type="text" name="Téléphone" placeholder="Telephone "size="20" required/>
                <br><br>
                <label>Email</label>
                <input type="Email" name= "Email" required/>
                <br><br>
                Type de personne<br>
                <select name= "Type" required>
                  <option>Etudiant</option>
                  <option>Professeur</option>
                        <option>Administrateur</option>
                </select>
                <br><br>
                <input type="submit" value="Valider" onClick="alert('Voulez-vous vraiment enregistrer')" name= "Envoyer"/>
              </form>
            </fieldset>
                </div>
                </div>
              </div>
            
          </div>
        </div>
      </div>
    </section>
        <br> <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br><br><br> <br><br><br><br>
    <section class="ftco-section ftco-no-pb">
			<div class="container">
				<div class="row no-gutters">
					<div class="col-md-6 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/staff.jpg);">
					</div>
					<div class="col-md-6 wrap-about py-md-5 ftco-animate">
	          <div class="heading-section p-md-5">
	            <h2 class="mb-4">Ecole supérieure d’infotronique d’Haïti</h2>

	            <p>Deux domaines :
                Sciences informatiques
                Gestion des entreprises.
                – Les diplômes proposés à l’ESIH dans les deux domaines d’enseignement sont de type
                L-Pro, M1 Pro
                – M2-Pro délocalisé dans la spécialité suivante : Marketing et Communication (M2CM de l’Université d’Oudja, Maroc)
                – M2 délocalisé en Administration des Entreprises (MAE) de l’Institut d’Administration des Entreprises (IAE) de Nice, France (à partir d’octobre 2019).</p>
	            <p>Fondée en 1995, Enseignement Supérieure, Membre titulaire AUF, reconnu par le Ministère de l’éducation (MENFP), de la Conférence des Recteurs et des Présidents des Universités Haïtiennes (CORPUHA), de l’Agence Internationale des Universités (AIU), du réseau vocationnel de l’Unesco UNEVOC, et de l’Association Haïtienne pour le développement des TIC (AHTIC).</p>
	          </div>
					</div>
				</div>
			</div>
		</section>

		<section class="ftco-counter img" id="section-counter">
    	<div class="container">
    		<div class="row">
          <div class="col-md-6 col-lg-3 justify-content-center counter-wrap ftco-animate">
            <div class="block-18 py-4 mb-4">
              <div class="text text-border d-flex align-items-center">
                
                
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 justify-content-center counter-wrap ftco-animate">
            <div class="block-18 py-4 mb-4">
              <div class="text text-border d-flex align-items-center">
              
             
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 justify-content-center counter-wrap ftco-animate">
            <div class="block-18 py-4 mb-4">
              <div class="text text-border d-flex align-items-center">
               
              
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 justify-content-center counter-wrap ftco-animate">
            <div class="block-18 py-4 mb-4">
              <div class="text d-flex align-items-center">
             
              </div>
            </div>
          </div>
        </div>
    	</div>
    </section>

    <section class="ftco-section testimony-section">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
		
            <div class="row">
              <div class="col-md-12 text-center">
      
                <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      Copyright &copy;<script>document.write(new Date().getFullYear());</script> Designed by Djey <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">djey Design</a>
      <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
              </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>