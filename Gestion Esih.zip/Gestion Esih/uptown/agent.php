<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Uptown - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">ESIH</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Acceuil</a></li>
	          <li class="nav-item"><a href="formulaire.php" class="nav-link">Enregistre Personnes</a></li>
	          <li class="nav-item active"><a href="agent.php" class="nav-link">Liste des Personnes</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2 ftco-degree-bg js-fullheight" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Acceuil <i class="ion-ios-arrow-forward"></i></a></span> <span>Liste des Personnes <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Liste des Personne</h1>
          </div>
        </div>
      </div>
    </section>
      <br><br><br>

      <table class="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nom</th>
          <th scope="col">Prenom</th>
          <th scope="col">Sexe</th>
          <th scope="col">Date de naissance</th>
          <th scope="col">Nationalite</th>
          <th scope="col">Telephone</th>
          <th scope="col">Email</th>
          <th scope="col">Type de personne</th>
          
        </tr>
      </thead>
      <tbody>
        
<?php
if(isset($_SESSION['Personnel'])){
if(isset($_SESSION['recherche'])){
 echo("<tr>");
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['code'].'</td>');                     
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['nom'].'</td>');                
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['prenom'].'</td>');               
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['Sexe'].'</td>');
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['Date_Naissance'].'</td>');
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['Nationalité'].'</td>');                
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['Téléphone'].'</td>');
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['Email'].'</td>');
 echo('<td>'.$_SESSION['Personnel'][$_SESSION['recherche']]['Type'].'</td>');
 echo("</tr>");
}
}

?>



      </tbody>
    </table>

    <br><br>
    <table class="table">
      <thead style="background-color:pink;">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nom</th>
          <th scope="col">Prenom</th>
          <th scope="col">Sexe</th>
          <th scope="col">Date de naissance</th>
          <th scope="col">Nationalite</th>
          <th scope="col">Telephone</th>
          <th scope="col">Email</th>
          <th scope="col">Type de personne</th>
          
        </tr>
      </thead>
      <tbody>
              
      <?php
      if(isset($_SESSION['Personnel'])){
          if(!empty($_SESSION['Personnel'])){
      foreach($_SESSION['Personnel'] as $t){
              echo("
                  <tr>
                      <td>$t[code]</td>
                      <td>$t[nom]</td>
                      <td>$t[prenom]</td>
                      <td>$t[Sexe]</td>
                      <td>$t[Date_Naissance]</td>
                      <td>$t[Nationalité]</td>
                      <td>$t[Téléphone]</td>
                      <td>$t[Email]</td>
                      <td>$t[Type]</td>
                  </tr>
              
              ");
              }
          }
      }
      ?>



      </tbody>
    </table>


		<section class="ftco-section ftco-agent">
    	<div class="container">
        <div class="row">
        	<div class="col-md-3">
        		<div class="agent">
    				
    				</div>
        	</div>
        </div>
    	</div>
    </section>

    <footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
         
           
        <div class="row">
			<div class="col-md-12 text-center">
	  
			  <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
	Copyright &copy;<script>document.write(new Date().getFullYear());</script> Designed by Djey <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">djey Design</a>
	<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
			</div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>